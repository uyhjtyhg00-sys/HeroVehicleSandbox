#include "HeroPlayerController.h"

#include "Blueprint/UserWidget.h"
#include "Engine/World.h"
#include "GameFramework/Pawn.h"
#include "Framework/Application/SlateApplication.h"
#include "Engine/GameViewportClient.h"
#include "Engine/Engine.h"
#include "HeroCharacter.h"
#include "HeroGameModeBase.h"
#include "HeroHUDWidget.h"
#include "HeroHealthComponent.h"
#include "HeroMainMenuWidget.h"
#include "HeroSettingsWidget.h"
#include "HeroTeamComponent.h"
#include "HeroVehicleModeComponent.h"
#include "HeroWeaponComponent.h"
#include "InputCoreTypes.h"

AHeroPlayerController::AHeroPlayerController()
{
    bShowMouseCursor = true;
    HeroCharacterClass = AHeroCharacter::StaticClass();
}

void AHeroPlayerController::BeginPlay()
{
    Super::BeginPlay();
    EnsureHeroPawnPossessed();
    ShowMainMenu();
}

void AHeroPlayerController::Tick(const float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);
    UpdateHUDFromPawn();
}

void AHeroPlayerController::SetupInputComponent()
{
    Super::SetupInputComponent();
    if (InputComponent)
    {
        InputComponent->BindAction(TEXT("PauseMenu"), IE_Pressed, this, &AHeroPlayerController::TogglePauseMenu);
    }
}

void AHeroPlayerController::ShowMainMenu()
{
    ClearMenu();
    if (HeroHUD && HeroHUD->IsInViewport())
    {
        HeroHUD->RemoveFromParent();
    }

    UClass* WidgetClass = MainMenuWidgetClass ? MainMenuWidgetClass.Get() : UHeroMainMenuWidget::StaticClass();
    CurrentMenu = CreateWidget<UHeroMainMenuWidget>(this, WidgetClass);
    if (CurrentMenu)
    {
        CurrentMenu->AddToViewport(20);
    }
    SetMenuInputMode();
}

void AHeroPlayerController::ShowHUD()
{
    EnsureHeroPawnPossessed();
    ClearMenu();

    if (!HeroHUD)
    {
        UClass* WidgetClass = HUDWidgetClass ? HUDWidgetClass.Get() : UHeroHUDWidget::StaticClass();
        HeroHUD = CreateWidget<UHeroHUDWidget>(this, WidgetClass);
    }

    if (HeroHUD && !HeroHUD->IsInViewport())
    {
        HeroHUD->AddToViewport(5);
    }

    SetGameInputMode();
}

void AHeroPlayerController::ShowSettingsMenu()
{
    bSettingsOpenedFromGame = HeroHUD && HeroHUD->IsInViewport();
    ClearMenu();
    UClass* WidgetClass = SettingsWidgetClass ? SettingsWidgetClass.Get() : UHeroSettingsWidget::StaticClass();
    CurrentMenu = CreateWidget<UHeroSettingsWidget>(this, WidgetClass);
    if (CurrentMenu)
    {
        CurrentMenu->AddToViewport(30);
    }
    SetMenuInputMode();
}

void AHeroPlayerController::ReturnFromSettings()
{
    ClearMenu();
    if (bSettingsOpenedFromGame)
    {
        ShowHUD();
    }
    else
    {
        ShowMainMenu();
    }
}

void AHeroPlayerController::TogglePauseMenu()
{
    if (CurrentMenu)
    {
        ReturnFromSettings();
        return;
    }

    ShowSettingsMenu();
}

void AHeroPlayerController::StartSandboxFromMenu()
{
    EnsureHeroPawnPossessed();

    if (APawn* ControlledPawn = GetPawn())
    {
        ControlledPawn->EnableInput(this);
    }

    ShowHUD();
}

void AHeroPlayerController::StartCombatTestFromMenu()
{
    EnsureHeroPawnPossessed();
    AssignPlayerTeam(EHeroTeam::TeamA);
    if (AHeroGameModeBase* GM = GetWorld() ? GetWorld()->GetAuthGameMode<AHeroGameModeBase>() : nullptr)
    {
        GM->StartCombatTestMode();
    }
    ShowHUD();
}

void AHeroPlayerController::StartCustomGameFromMenu()
{
    EnsureHeroPawnPossessed();
    AssignPlayerTeam(EHeroTeam::TeamA);
    if (AHeroGameModeBase* GM = GetWorld() ? GetWorld()->GetAuthGameMode<AHeroGameModeBase>() : nullptr)
    {
        GM->StartCustomGameMode(EHeroGameModeType::Control, 6);
    }
    ShowHUD();
}

UHeroHUDWidget* AHeroPlayerController::GetHeroHUD() const
{
    return HeroHUD;
}

void AHeroPlayerController::ClearMenu()
{
    if (CurrentMenu)
    {
        CurrentMenu->RemoveFromParent();
        CurrentMenu = nullptr;
    }
}

AHeroCharacter* AHeroPlayerController::EnsureHeroPawnPossessed()
{
    if (AHeroCharacter* CurrentHero = Cast<AHeroCharacter>(GetPawn()))
    {
        SetViewTarget(CurrentHero);
        return CurrentHero;
    }

    UWorld* World = GetWorld();
    UClass* PawnClass = HeroCharacterClass ? HeroCharacterClass.Get() : AHeroCharacter::StaticClass();
    if (!World || !PawnClass)
    {
        return nullptr;
    }

    APawn* PreviousPawn = GetPawn();
    FVector HeroSpawnLocation = FVector(0.0f, 0.0f, 120.0f);
    FRotator SpawnRotation = FRotator::ZeroRotator;

    if (PreviousPawn)
    {
        HeroSpawnLocation = PreviousPawn->GetActorLocation();
        SpawnRotation = PreviousPawn->GetActorRotation();
    }
    else
    {
        FVector ViewLocation = FVector::ZeroVector;
        FRotator ViewRotation = FRotator::ZeroRotator;
        GetPlayerViewPoint(ViewLocation, ViewRotation);
        if (!ViewLocation.IsNearlyZero())
        {
            HeroSpawnLocation = ViewLocation;
            SpawnRotation = ViewRotation;
        }
    }

    FActorSpawnParameters SpawnParams;
    SpawnParams.Owner = this;
    SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

    AHeroCharacter* NewHero = World->SpawnActor<AHeroCharacter>(PawnClass, HeroSpawnLocation, FRotator(0.0f, SpawnRotation.Yaw, 0.0f), SpawnParams);
    if (!NewHero)
    {
        return nullptr;
    }

    Possess(NewHero);
    SetControlRotation(FRotator(0.0f, SpawnRotation.Yaw, 0.0f));
    SetViewTarget(NewHero);

    if (PreviousPawn && PreviousPawn != NewHero)
    {
        PreviousPawn->Destroy();
    }

    return NewHero;
}

void AHeroPlayerController::AssignPlayerTeam(const EHeroTeam Team)
{
    if (AHeroCharacter* Hero = Cast<AHeroCharacter>(GetPawn()))
    {
        if (UHeroTeamComponent* TeamComponent = Hero->GetTeamComponent())
        {
            TeamComponent->SetTeam(Team);
        }
        if (UHeroHealthComponent* Health = Hero->GetHealthComponent())
        {
            Health->ResetHealth();
        }
    }
}

void AHeroPlayerController::SetMenuInputMode()
{
    bShowMouseCursor = true;
    bEnableClickEvents = true;
    bEnableMouseOverEvents = true;
    SetIgnoreMoveInput(true);
    SetIgnoreLookInput(true);
    FInputModeUIOnly InputMode;
    InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
    SetInputMode(InputMode);
}

void AHeroPlayerController::SetGameInputMode()
{
    EnsureHeroPawnPossessed();

    bShowMouseCursor = false;
    bEnableClickEvents = false;
    bEnableMouseOverEvents = false;

    SetIgnoreMoveInput(false);
    SetIgnoreLookInput(false);
    ResetIgnoreMoveInput();
    ResetIgnoreLookInput();

    FInputModeGameOnly InputMode;
    InputMode.SetConsumeCaptureMouseDown(false);
    SetInputMode(InputMode);

    if (GEngine && GEngine->GameViewport)
    {
        GEngine->GameViewport->SetMouseCaptureMode(EMouseCaptureMode::CapturePermanently_IncludingInitialMouseDown);
        GEngine->GameViewport->SetMouseLockMode(EMouseLockMode::LockAlways);
    }

    if (FSlateApplication::IsInitialized())
    {
        FSlateApplication::Get().SetAllUserFocusToGameViewport(EFocusCause::SetDirectly);
    }

    FlushPressedKeys();
}

void AHeroPlayerController::UpdateHUDFromPawn()
{
    if (!HeroHUD)
    {
        return;
    }

    AHeroCharacter* Hero = Cast<AHeroCharacter>(GetPawn());
    if (!Hero)
    {
        return;
    }

    UHeroHealthComponent* Health = Hero->GetHealthComponent();
    UHeroWeaponComponent* Weapon = Hero->GetWeaponComponent();
    UHeroVehicleModeComponent* VehicleMode = Hero->GetVehicleModeComponent();
    UHeroTeamComponent* Team = Hero->GetTeamComponent();

    if (VehicleMode)
    {
        HeroHUD->SetPlayerMode(VehicleMode->GetPlayerMode());
    }
    if (Health)
    {
        HeroHUD->SetHealth(Health->GetHealth(), Health->GetMaxHealth());
        HeroHUD->SetVehicleHealth(Health->GetHealth() * 1.8f, Health->GetMaxHealth() * 1.8f);
    }
    if (Weapon)
    {
        HeroHUD->SetWeaponName(Weapon->GetWeaponName());
        HeroHUD->SetAmmo(Weapon->GetAmmoInMagazine(), Weapon->GetReserveAmmo());
        HeroHUD->SetReloading(Weapon->IsReloading());
        HeroHUD->SetWeaponHeat(Weapon->GetWeaponHeat01());
    }

    if (const AHeroGameModeBase* HeroGM = GetWorld() ? GetWorld()->GetAuthGameMode<AHeroGameModeBase>() : nullptr)
    {
        HeroHUD->SetObjectiveStatus(
            HeroGM->GetCustomGameSettings().GameModeType,
            Team ? Team->GetTeam() : EHeroTeam::None,
            HeroGM->GetPrimaryObjectiveState(),
            HeroGM->GetPrimaryObjectiveProgress01(),
            HeroGM->GetPrimaryObjectiveState() == EHeroObjectiveState::Contested);
        HeroHUD->SetBotStatus(HeroGM->GetAliveBotCount(), HeroGM->GetTotalSpawnedBotCount());
    }
}

void AHeroPlayerController::ToggleSettingsMenu()
{
    if (CurrentMenu)
    {
        ClearMenu();
        ShowHUD();
        return;
    }

    ShowSettingsMenu();
}
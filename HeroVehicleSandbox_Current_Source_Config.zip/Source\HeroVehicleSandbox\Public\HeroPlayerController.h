#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "HeroTypes.h"
#include "HeroPlayerController.generated.h"

class UHeroHUDWidget;
class UHeroMainMenuWidget;
class UHeroSettingsWidget;
class UUserWidget;
class AHeroCharacter;

UCLASS()
class HEROVEHICLESANDBOX_API AHeroPlayerController : public APlayerController
{
    GENERATED_BODY()

public:
    AHeroPlayerController();
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
    virtual void SetupInputComponent() override;

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    void ShowMainMenu();

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    void ShowHUD();

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    void ShowSettingsMenu();

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    void ReturnFromSettings();

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    void TogglePauseMenu();

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    void StartSandboxFromMenu();

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    void ToggleSettingsMenu();

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    void StartCombatTestFromMenu();

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    void StartCustomGameFromMenu();

    UFUNCTION(BlueprintCallable, Category="Hero|UI")
    UHeroHUDWidget* GetHeroHUD() const;

private:
    void ClearMenu();
    AHeroCharacter* EnsureHeroPawnPossessed();
    void AssignPlayerTeam(EHeroTeam Team);
    void SetMenuInputMode();
    void SetGameInputMode();
    void UpdateHUDFromPawn();

private:
    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Hero|Player", meta=(AllowPrivateAccess="true"))
    TSubclassOf<AHeroCharacter> HeroCharacterClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Hero|UI", meta=(AllowPrivateAccess="true"))
    TSubclassOf<UHeroHUDWidget> HUDWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Hero|UI", meta=(AllowPrivateAccess="true"))
    TSubclassOf<UHeroMainMenuWidget> MainMenuWidgetClass;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Hero|UI", meta=(AllowPrivateAccess="true"))
    TSubclassOf<UHeroSettingsWidget> SettingsWidgetClass;

    UPROPERTY(Transient)
    TObjectPtr<UUserWidget> CurrentMenu;

    UPROPERTY(Transient)
    TObjectPtr<UHeroHUDWidget> HeroHUD;

    bool bSettingsOpenedFromGame = false;
};

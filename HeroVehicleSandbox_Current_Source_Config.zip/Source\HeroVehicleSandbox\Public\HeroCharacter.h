#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "HeroTypes.h"
#include "HeroCharacter.generated.h"

class UCameraComponent;
class UHeroHealthComponent;
class UHeroWeaponComponent;
class UHeroVehicleModeComponent;
class UHeroTeamComponent;

UCLASS()
class HEROVEHICLESANDBOX_API AHeroCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category="Hero|Camera")
    void ApplyViewKick(float PitchKickDegrees, float YawKickDegrees = 0.0f);
AHeroCharacter();

    virtual void BeginPlay() override;
    virtual void Tick(float DeltaSeconds) override;
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;
    virtual void OnStartCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust) override;
    virtual void OnEndCrouch(float HalfHeightAdjust, float ScaledHalfHeightAdjust) override;

    UCameraComponent* GetFirstPersonCamera() const;
    UHeroWeaponComponent* GetWeaponComponent() const;
    UHeroHealthComponent* GetHealthComponent() const;
    UHeroVehicleModeComponent* GetVehicleModeComponent() const;
    UHeroTeamComponent* GetTeamComponent() const;

    UFUNCTION(BlueprintCallable, Category="Hero|Settings")
    void ApplyAimSettings(const FHeroAimSettings& NewSettings);

    UFUNCTION(BlueprintCallable, Category="Hero|Settings")
    const FHeroAimSettings& GetAimSettings() const;

    UFUNCTION(BlueprintCallable, Category="Hero|Movement")
    bool IsHeroCrouching() const;

protected:
    void MoveForward(float Value);
    void MoveRight(float Value);
    void Turn(float Value);
    void LookUp(float Value);
    void StartFire();
    void StopFire();
    void StartAim();
    void StopAim();
    void Reload();
    void StartHeroCrouch();
    void StopHeroCrouch();
    void ToggleVehicleMode();
    void Interact();

    UFUNCTION()
    void HandleDeath();

private:
    void ConfigureCharacterMovement();
    void LoadAimSettings();
    void UpdateCameraHeight(float DeltaSeconds);
    float GetAirMovementScale() const;

    UFUNCTION()
    void ApplyModeToComponents(EHeroPlayerMode NewMode);

private:
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Hero|Camera", meta=(AllowPrivateAccess="true"))
    TObjectPtr<UCameraComponent> FirstPersonCamera;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Hero|Components", meta=(AllowPrivateAccess="true"))
    TObjectPtr<UHeroWeaponComponent> WeaponComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Hero|Components", meta=(AllowPrivateAccess="true"))
    TObjectPtr<UHeroHealthComponent> HealthComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Hero|Components", meta=(AllowPrivateAccess="true"))
    TObjectPtr<UHeroVehicleModeComponent> VehicleModeComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Hero|Components", meta=(AllowPrivateAccess="true"))
    TObjectPtr<UHeroTeamComponent> TeamComponent;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Hero|Movement", meta=(AllowPrivateAccess="true"))
    float HumanWalkSpeed = 550.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Hero|Movement", meta=(AllowPrivateAccess="true"))
    float VehicleModeWalkSpeed = 950.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Hero|Movement", meta=(AllowPrivateAccess="true"))
    float CrouchWalkSpeed = 330.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Hero|Movement", meta=(AllowPrivateAccess="true"))
    float StandingEyeHeight = 74.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Hero|Movement", meta=(AllowPrivateAccess="true"))
    float HeroCrouchedEyeHeight = 48.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Hero|Movement", meta=(AllowPrivateAccess="true"))
    float CameraHeightInterpSpeed = 16.0f;

    // Overwatch-like air control: the player can still correct direction while airborne,
    // but the strength is intentionally lower than grounded input.
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Hero|Movement", meta=(AllowPrivateAccess="true"))
    float AirMovementInputScale = 0.46f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Hero|Settings", meta=(AllowPrivateAccess="true"))
    FHeroAimSettings AimSettings;
};



